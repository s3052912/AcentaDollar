function deleteNote(noteId) {
  fetch("/delete-note", {
    method: "POST",
    body: JSON.stringify({ noteId: noteId }),
  }).then((_res) => {
    window.location.href = "/";
  });
}

function deleteExpense(expenseId) {
  fetch("/delete-expense", {
    method: "POST",
    body: JSON.stringify({ expenseId: expenseId }),
  }).then((_res) => {
    window.location.href = "/expenses";
  });
}

function deleteSaving(savingId) {
  fetch("/delete-saving", {
    method: "POST",
    body: JSON.stringify({ savingId: savingId }),
  }).then((_res) => {
    window.location.href = "/savings";
  });
}